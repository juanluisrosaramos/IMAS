/**
 *  IMAS base code for the practical work.
 *  Copyright (C) 2014 DEIM - URV
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package cat.urv.imas.agent;

import jade.core.AID;


/**
 * The main Coordinator agent. 
 * TODO: This coordinator agent should get the game settings from the System
 * agent every round and share the necessary information to other coordinators.
 */
public class HarvesterAgent extends ImasAgent {
    private int row, col;
    private AID harvesterCoordinatorAgent;
    
    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }
    
    /**
     * Builds the coordinator agent.
     */
    public HarvesterAgent() {
        super(AgentType.HARVESTER);
    }
    
    @Override
    protected void setupConcrete() {
        Object[] args = getArguments();
        this.setRow((int)args[0]);
        this.setCol((int)args[1]);
        this.harvesterCoordinatorAgent = this.searchAgent(AgentType.HARVESTER_COORDINATOR);
    }
}
